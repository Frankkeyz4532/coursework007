<?php

header('Location: dashboard.php');

?>