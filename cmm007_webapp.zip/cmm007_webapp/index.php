

    <?php include('header.php'); ?>

    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-slides owl-carousel">
            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img" style="background-image: url(img/bg-img/bg1.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                            <div class="hero-slides-content" data-animation="fadeInUp" data-delay="100ms">
                                <h2 data-animation="fadeInUp" data-delay="300ms">Delicious Hamburger</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Come check our treasure box of recipes and uncover a world of delicious possibilities! From hearty mains to sweet treats, there's something to tantalize every taste bud. Let's get cooking and make every meal an adventure!</p>
                                <a href="recipes.php" class="btn delicious-btn" data-animation="fadeInUp" data-delay="1000ms">View this Recipe</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img" style="background-image: url(img/bg-img/bg6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                            <div class="hero-slides-content" data-animation="fadeInUp" data-delay="100ms">
                                <h2 data-animation="fadeInUp" data-delay="300ms">Tasty Vegetables</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Come check our treasure box of recipes and uncover a world of delicious possibilities! From hearty mains to sweet treats, there's something to tantalize every taste bud. Let's get cooking and make every meal an adventure!</p>
                                <a href="recipes.php" class="btn delicious-btn" data-animation="fadeInUp" data-delay="1000ms">View this Recipe</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Single Hero Slide -->
            <div class="single-hero-slide bg-img" style="background-image: url(img/bg-img/bg7.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
                            <div class="hero-slides-content" data-animation="fadeInUp" data-delay="100ms">
                                <h2 data-animation="fadeInUp" data-delay="300ms">Homemade Smoothie</h2>
                                <p data-animation="fadeInUp" data-delay="700ms">Come check our treasure box of recipes and uncover a world of delicious possibilities! From hearty mains to sweet treats, there's something to tantalize every taste bud. Let's get cooking and make every meal an adventure!</p>
                                <a href="recipes.php" class="btn delicious-btn" data-animation="fadeInUp" data-delay="1000ms">View this Recipe</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Hero Area End ##### -->

    <!-- ##### Top Catagory Area Start ##### -->
    <section class="top-catagory-area section-padding-80-0">
        <div class="container">
            <div class="row">
                <!-- Top Catagory Area -->
                <div class="col-12 col-lg-6">
                    <div class="single-top-catagory">
                        <img src="img/bg-img/bg2.jpg" alt="">
                        <!-- Content -->
                        <div class="top-cta-content">
                            <h3>Are you a Recipe Seeker?</h3>
                            <h6>You can view recipes</h6>
                            <a href="recipes.php" class="btn delicious-btn">View recipes</a>
                        </div>
                    </div>
                </div>
                <!-- Top Catagory Area -->
                <div class="col-12 col-lg-6">
                    <div class="single-top-catagory">
                        <img src="img/bg-img/bg3.jpg" alt="">
                        <!-- Content -->
                        <div class="top-cta-content">
                            <h3>Are you a Chef or Cook?</h3>
                            <h6>View, Edit &amp; Add recipe</h6>
                            <a href="cook/sign-in.php" class="btn delicious-btn">Sign-in as a Cook</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Top Catagory Area End ##### -->

    <!-- ##### Best Receipe Area Start ##### -->
    <section class="best-receipe-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                        <h3>Latest Recipes</h3>
                    </div>
                </div>
            </div>

            <div class="row">
                
                <?php while ($recipe = mysqli_fetch_array($recipe_query)) { ?>
                <!-- Single Best Receipe Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-best-receipe-area mb-30">
                        <img src="uploads/recipes/<?= $recipe['image']; ?>" alt="">
                        <div class="receipe-content">
                            <a href="single-recipe.php?rid=<?= $recipe['id']; ?>">
                                <h5> <?= $recipe['name']; ?></h5>
                            </a>
                            <div class="ratings">
                                <i class="fa fa-star" aria-hidden="true"></i><span class="mx-2"> <?= $loader->recipeAuthor($recipe['user_id']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
             <?php } ?>


            </div>
        </div>
    </section>
    <!-- ##### Best Receipe Area End ##### -->

    <!-- ##### CTA Area Start ##### -->
    <section class="cta-area bg-img bg-overlay" style="background-image: url(img/bg-img/bg4.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <!-- Cta Content -->
                    <div class="cta-content text-center">
                        <h2>About Us</h2>
                        <p>Come check our treasure box of recipes and uncover a world of delicious possibilities! From hearty mains to sweet treats, there's something to tantalize every taste bud. Let's get cooking and make every meal an adventure!</p>
                        <a href="recipes.php" class="btn delicious-btn">Discover all Recipes</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### CTA Area End ##### -->

    <!-- ##### Small Receipe Area Start ##### -->
    <section class="small-receipe-area section-padding-80-0">
        <div class="container">
            
             <div class="row">
                <div class="col-12">
                    <div class="section-heading">
                        <h3>Latest Recipe Categories</h3>
                    </div>
                </div>
            </div>
            
            <div class="row">

           
            
            
            <?php while( $category = mysqli_fetch_array( $cat_query ) ){  ?>
                <!-- Small Receipe Area -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-small-receipe-area d-flex align-items-center">
                        <!-- Receipe Thumb -->
                        <div class="receipe-thumb">
                            <img src="/uploads/category/<?= $category['image']; ?>" alt="">
                        </div>
                        <!-- Receipe Content -->
                        <div class="receipe-content">
                            <span><?= $category['created_at']; ?></span>
                            <a href="recipes.php?cid=<?= $category['id']; ?>">
                                <h5><?= $category['name']; ?></h5>
                            </a>
                            <div class="ratings align-items-center row mx-0">
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <p class="mx-2"><?= $loader->recipeCategoryAuthor($category['chef_id']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>

            </div>
        </div>
    </section>
    <!-- ##### Small Receipe Area End ##### -->

    <?php include('footer.php') ?>