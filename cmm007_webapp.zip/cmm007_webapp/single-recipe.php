<?php include('header.php');

if (isset($_GET['rid']) && $_GET['rid'] !== null) {
    $recipe_id = $_GET['rid'];
    $recipe_query = mysqli_query($con, "SELECT * FROM recipes WHERE `id` = $recipe_id");
    $recipe = mysqli_fetch_array($recipe_query);

    if ($recipe <= 0) {
        $link = $loader->getLink('my-recipes.php');
        echo "<script>alert('Recipe does not exist'); window.location.href='" . $link . "'</script>";
        exit();
    }
} else {
    $link = $loader->getLink('my-recipes.php');
    echo "<script>alert('Recipe does not exist'); window.location.href='" . $link . "'</script>";
    exit();
}



?>

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/breadcumb3.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-text text-center">
                        <h2>Single Recipe</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcumb Area End ##### -->

    <div class="receipe-post-area section-padding-80">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="receipe-headline mb-2 my-md-5">
                        
                        <?php
                        
                         $date = $recipe['created_at'];
                    // Convert the date string into the desired format
                    $formatted_day = date('d', strtotime($date));
                    $formatted_month = date('F', strtotime($date));
                    $formatted_year = date('Y', strtotime($date));
                        
                        ?>
                        
                        <span><?= $formatted_month ?> <?= $formatted_day ?>, <?=  $formatted_year ?></span>
                        <h2><?= $recipe['name']; ?></h2>
                        <div class="receipe-duration">
                            <h6>Prep: <?= $recipe['preparation_time']; ?>. || Serving: <?= $recipe['servings']; ?> people</h6>
                            <p>
                                <?= $recipe['description']; ?>
                                </p>
                            <!-- <h6>Cook: 30 mins</h6>
                            <h6>Yields: 8 Servings</h6> -->
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="receipe-ratings text-right mt-0 mb-5 my-md-5">
                        <div class="mb-3">
                            <i class="fa fa-star" aria-hidden="true"></i>
                            <span><?= $loader->recipeAuthor($recipe['user_id']); ?></span>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

        <!-- Receipe Slider -->
        <div class="container mb-5">
            <div class="row">
                <div class="col-12">
                    <div class="receipe-slider owl-carousel">
                        <img src="img/bg-img/bg5.jpg" alt="">
                        <img src="img/bg-img/bg5.jpg" alt="">
                        <img src="img/bg-img/bg5.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>

        <!-- Receipe Content Area -->
        <div class="receipe-content-area">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-8">
                        <h4 class="mb-4">Preparation Steps</h4>

                          <?= $recipe['instructions']; ?>
                        
                    </div>

                    <!-- Ingredients -->
                    <div class="col-12 col-lg-4">
                        <div class="ingredients">
                            <h4>Ingredients</h4>
                             <?= $recipe['ingredients']; ?>
                        </div>
                    </div>
                </div>

                <!-- <div class="row">
                    <div class="col-12">
                        <div class="section-heading text-left">
                            <h3>Leave a comment</h3>
                        </div>
                    </div>
                </div> -->

                <!-- <div class="row">
                    <div class="col-12">
                        <div class="contact-form-area">
                            <form action="#" method="post">
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <input type="text" class="form-control" id="name" placeholder="Name">
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <input type="email" class="form-control" id="email" placeholder="E-mail">
                                    </div>
                                    <div class="col-12">
                                        <input type="text" class="form-control" id="subject" placeholder="Subject">
                                    </div>
                                    <div class="col-12">
                                        <textarea name="message" class="form-control" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                    </div>
                                    <div class="col-12">
                                        <button class="btn delicious-btn mt-30" type="submit">Post Comments</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
    </div>

    <?php include('footer.php'); ?>