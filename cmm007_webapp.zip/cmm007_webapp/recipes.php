<?php

include('header.php');
    
if( (isset($_GET['cid'])) && ($_GET['cid'] !== null) ){
$cid = $_GET['cid'];
$recipe_query = mysqli_query($con,"SELECT * FROM recipes where category_id=$cid");
}else{
 $recipe_query = mysqli_query($con,"SELECT * FROM recipes");   
}
    
    ?>

    <!-- ##### Breadcumb Area Start ##### -->
    <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/breadcumb2.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcumb-text text-center">
                        <h2>All Recipes</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="blog-area section-padding-80">
        <div class="container">
            <div class="row blog-posts-area">


                <!-- Single Blog Area -->
                  <?php while( $recipe = mysqli_fetch_array($recipe_query) ) { ?>
                <div class="col-md-6 col-lg-4 single-blog-area mb-80">
                    <!-- Thumbnail -->
                    <div class="blog-thumbnail">
                        <img src="uploads/recipes/<?= $recipe['image']; ?>" alt="">
                        
                        <?php
                        
                    $date = $recipe['created_at'];
                    // Convert the date string into the desired format
                    $formatted_day = date('d', strtotime($date));
                    $formatted_month = date('F', strtotime($date));
                    $formatted_year = date('Y', strtotime($date));

                        ?>
                        <!-- Post Date -->
                        <div class="post-date">
                            <a href="single-recipe.php?rid=<?= $recipe['id']; ?>"><span><?= $formatted_day ?></span><?= $formatted_month ?> <br> <?= $formatted_year ?></a>
                        </div>
                    </div>
                    <!-- Content -->
                    <div class="blog-content">
                        <a href="single-recipe.php?rid=<?= $recipe['id']; ?>" class="post-title"><?= $recipe['name']; ?></a>
                        <div class="meta-data">by <a href="#"> <?= $loader->recipeAuthor($recipe['user_id']); ?> </a>
                        </div>
                        <p> <?= $recipe['description']; ?> </p>
                        
                        <div class="row mt-30">
                            <a href="single-recipe.php?rid=<?= $recipe['id']; ?>" class="col mx-2 btn delicious-btn">Read More</a>
                        </div>  
                        
                    </div>
                </div>
                <?php } ?>


            </div>


        </div>
    </div>
    <!-- ##### Blog Area End ##### -->

    <?php include('footer.php') ?>